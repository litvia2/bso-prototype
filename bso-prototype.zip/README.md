
# Behavioral Sentiment Overlay (BSO)

> **Author:** Anna Litvinova — original concept and prototype implementation.  
> **Tagline:** A sentiment-adjusted overlay for VaR/ES that fuses supervised structure with unsupervised anomaly detection.

## Why
Traditional VaR/ES is history-bound and blind to new behavioral shocks. BSO injects a forward-looking **behavioral anomaly score** into capital estimates to:
- tighten risk buffers in anomalous regimes, and
- optionally act as a **filter** for opportunity (avoid trading into panic/crowding).

## What
**Overlay rule:**
\`
VaR_adj(t) = VaR_base(t) * (1 + alpha * AnomalyScore(t))
\`

- `VaR_base`: rolling-hist or EWMA/GARCH (your choice).
- `AnomalyScore ∈ [0,1]`: from a rolling IsolationForest over a **sentiment block**:
  - RSI(14), VIX level & term slope, Put/Call ratio, realized vol (RV20).

**Stability controls:** hysteresis (3-day confirm) and capped daily score change.

## Repo Layout
```
bso-prototype/
├─ README.md
├─ requirements.txt
├─ src/bso/core.py           # feature engineering, VaR engines, anomaly, overlay, evaluation
├─ scripts/run_bso.py        # CLI runner (yfinance or your CSV)
├─ notebooks/BSO_synthetic_demo.py  # quick synthetic demo
├─ tests/test_sanity.md
```

## Install
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

## Run (Live Data)
```bash
python scripts/run_bso.py --use-yf --start 2016-01-01 --end 2025-09-16 --var hist --alpha 0.3
```
- Pulls `^GSPC` and `^VIX` via yfinance.
- Computes sentiment features → rolling IsolationForest → anomaly score.
- Outputs coverage stats (Kupiec/Christoffersen), plots, and `bso_results.csv`.

## Run (Your CSV)
CSV format:
```
Date,Price,VIX,PutCall
2022-01-03,4796.56,16.60,0.65
2022-01-04,4793.54,16.84,0.68
```
Run:
```bash
python scripts/run_bso.py --csv mydata.csv --var hist --alpha 0.3
```

## Evaluate
- **Coverage:** Kupiec POF (breach frequency), Christoffersen independence (clustering). Target 99% VaR should pass both (p > 0.05).
- **Capital Stability:** compare std of `pct_change` of VaR series; aim for stability not whipsaw.
- **Tail Severity:** compare ES shortfall during stress windows (to add).

## Notes & Limitations
- Sentiment features are correlated; consider PCA for research, SHAP for explainability.
- `Put/Call` may need a vendor feed; a proxy is provided if missing (lower fidelity).
- Parameters to tune: `alpha`, IF `contamination`, confirm window, cap.
- Use **walk-forward** evaluation and pre-registered parameter sets.
- This is research code, not a production risk engine.

## Contribute
I want falsification and honest feedback:
- Does BSO improve VaR coverage **out-of-sample**?
- Does it reduce tail shortfall without bloating capital?
- Does the anomaly score help or hurt as a trading filter?

Open an issue with your results (data period, assets, params, plots). If this idea is garbage, tell me **why** — that’s progress.

— Anna
