
# Sanity Checks
- Run `python scripts/run_bso.py --use-yf --start 2016-01-01 --end 2025-09-16` and confirm:
  - Script completes, prints coverage metrics.
  - Generates plots.
  - Produces `bso_results.csv`.
- Run synthetic demo: `python notebooks/BSO_synthetic_demo.py`.
- Try CSV mode with `bso_input_template.csv` format.
